---
name: Authoring Agent Skills
description: Create Skills with YAML frontmatter and markdown body. Use when authoring Skills, writing SKILL.md files, or organizing Skill content.
---

# Authoring Agent Skills

## Quick start

Create a Skill in 3 steps:

1. **Make directory**: `~/.claude/skills/pdf-skill/`

2. **Write SKILL.md** with frontmatter + body:

```yaml
---
name: PDF Text Extraction
description: Extract text from PDFs. Use when working with PDF files or text extraction.
---

# PDF Text Extraction

## Quick start

```python
import pdfplumber
with pdfplumber.open("file.pdf") as pdf:
    text = pdf.pages[0].extract_text()
```
```

3. **Test**: Mention triggers from description ("PDF", "text extraction")

## File organization

Basic (single file):
```
my-skill/
├── SKILL.md
```

With advanced content (SKILL.md > 400 lines):
```
my-skill/
├── SKILL.md
├── ADVANCED.md
└── REFERENCE.md
```

See [reference.md](reference.md) for progressive disclosure patterns.

## Writing guidelines

- Concise: Assume Claude knows basics
- Under 500 lines in SKILL.md
- Specific description with user triggers
- Third person voice ("Extracts...", not "I extract...")

See [best-practices.md](best-practices.md) for full details.
